
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
short_version = '1.10.4'
version = '1.10.4'
full_version = '1.10.4'
git_revision = 'e46c2d78a27f25e66624a818276be57ef9458e60'
release = True

if not release:
    version = full_version
